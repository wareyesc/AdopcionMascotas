from django.contrib import admin
from apps.adopcion.models import Persona
# Register your models here.
admin.site.register(Persona)
